import React, { Component } from 'react';
import '../styles/App.css';
import {WeatherModal} from "./weather-modal";
import {API_CALL} from "../utils/constants";
import {WeatherData} from "../utils/weather-data";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {weather: null}
  }
  componentDidMount() {
    fetch(this.apiUrl(84094) + API_CALL).then(res => {
      return res.json();
    }).then(data => {
      const weather = new WeatherData(data);
      this.setState({weather: weather})
    })
  }

  apiUrl = (zipCode) => {
    return `http://api.openweathermap.org/data/2.5/forecast?zip=${zipCode},us`;
  }

  render() {
    return (
      <div className="App">
          {this.state.weather && WeatherModal(this.state.weather)}
      </div>
    );
  }
}

export default App;
