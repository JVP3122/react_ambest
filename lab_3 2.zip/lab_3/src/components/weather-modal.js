import React from 'react';
import '../styles/weather-modal.css';

export const WeatherModal = (weather) => {
    return (
        <div className='modalBody'>
            <div>
            <div>{weather.date}</div>
            </div>
            <div>
            <div>{weather.city}</div>
            </div>
            <div style={{display: 'flex'}}>
                <div>{weather.temp.toFixed(1)}</div>
                <img src={weather.imagePath} style={{width: 30, height: 30}}/>
            </div>
        </div>
    )
}