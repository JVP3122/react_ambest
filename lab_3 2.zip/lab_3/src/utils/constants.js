const API_KEY = 'b147d4eb0ce597bff1f36ab0fd74b5db';
export const API_CALL = `&APPID=${API_KEY}`;