export const IMAGE_PATH = {
    CLOUDY: require('../images/cloudy.svg'),
    RAIN: require('../images/rain.svg'),
    SNOW: require('../images/snowing.svg'),
    SUN: require('../images/sun.svg'),
    WINDY: require('../images/windy.svg')
}