import {IMAGE_PATH} from "./image-paths";

export class WeatherData {
    city;
    date;
    temp;
    imagePath;
    constructor(data) {
        this.city = data.city.name;
        let epoch = data.list[0].dt * 1000;
        this.date = new Date(epoch).toDateString();
        let fehrenheit = (9 / 5) * (data.list[0].main.temp - 270) + 32;
        this.temp = fehrenheit;
        let weather = data.list[0].weather[0].main;
        this.imagePath = getIcon(weather);
    }
}

const getIcon = (weather) => {
    switch (weather.toUpperCase()) {
        case 'CLEAR': {
            return IMAGE_PATH.WINDY;
        }
        case 'SUNNY': {
            return IMAGE_PATH.SUN;
        }
        case 'SNOW': {
            return IMAGE_PATH.SNOW;
        }
        case 'RAIN': {
            return IMAGE_PATH.RAIN;
        }
        case 'CLOUDS': {
            return IMAGE_PATH.CLOUDY;
        }
        default: {
            return IMAGE_PATH.SUN;
        }
    }
}