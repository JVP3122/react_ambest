
export const apiResponse = [{
    genre: 'Comedy',
    movies: ["Liar Liar", "Ace Ventura", "Yes Man", "Groundhog Day", "This Is The End"],
}, {
    genre: 'Suspense',
    movies: ["Conjuring", "Shutter Island", "Get Out", "The Shining"]
}, {
    genre: 'Kids',
    movies: ["Boss Baby", "My Little Pony", "Zootopia", "Leap", "Frozen", "Finding Nemo"]
}, {
    genre: 'Drama',
    movies: ["Forrest Gump", "Fight Club", "A Beautiful Mind", "The Pursuit Of Happyness"]
}];