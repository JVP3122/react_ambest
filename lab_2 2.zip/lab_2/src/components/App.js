import React, { Component } from 'react';
import '../styles/App.css';
import Sidebar from "./sidebar";
import MovieContainer from "./movie-detail-container";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {moviePicked: null}
  }
  render() {
    return (
      <div className="App">
          <Sidebar moviePicked={this.state.moviePicked} sendMovieToTopLevel={(movie) => this.setState({moviePicked: movie})}/>
          <MovieContainer movie={this.state.moviePicked}/>
      </div>
    );
  }
}

export default App;
