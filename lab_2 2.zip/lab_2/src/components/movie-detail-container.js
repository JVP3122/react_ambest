import React from 'react';
import '../styles/movie-detail-container.css';

export default class MovieContainer extends React.Component {

    displayMovies = (movie) => {
        return movie.movies.map((movie, i) => {
            return <div key={movie + i} style={{paddingLeft: 10, height: 30}}>{i +1} {movie}</div>
        })
    }

    render() {
        const {movie} = this.props;
        if (!movie) { return <div className='detailContainer'/>}
        return (
            <div className='detailContainer'>
                <h2>{movie.genre}</h2>
                {this.displayMovies(movie)}
            </div>
        )
    }
}