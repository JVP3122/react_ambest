import React from 'react';
import '../styles/movie-cell.css';

export default class MovieCell extends React.Component {
    render() {
        const {movieData, sendUpMovie, isSelected} = this.props;
        const cellStyle = isSelected ? 'selectedCell' : null;
        return (
            <div
                onClick={() => sendUpMovie(movieData)}
                className={`cellBody ${cellStyle}`}>
                {movieData.genre}</div>
        )
    }
}