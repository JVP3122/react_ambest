import React from 'react';
import '../styles/sidebar.css';
import MovieCell from "./movie-cell";
import {apiResponse} from "../api-service/api-response";

export default class Sidebar extends React.Component {

    displayMovieCells = () => {
        let response = apiResponse;
        return response.map((category, i) => {
            return <MovieCell key={category.genre + i} isSelected={this.props.moviePicked === category} sendUpMovie={(movie) => this.props.sendMovieToTopLevel(movie)} movieData={category}/>
        })
    }

    render() {
        return (
            <div className='sidebarBody'>
                <div>
                    <h3>Pick Genre</h3>
                </div>
                <div>
                    {this.displayMovieCells()}
                </div>
            </div>
        )
    }
}