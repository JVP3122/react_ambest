import React from 'react';
import '../styles/app.css'

export default class App extends React.Component {
    partyList = [];
    constructor(props) {
        super(props);
        this.state = {userInput: ''}
    }

    inputChanged = (e) => {
        this.setState({userInput: e.target.value})
    }

    addFriendToList = () => {
        this.partyList.push(this.state.userInput);
        this.setState({userInput: ''});
    }

    checkForEnter = (e) => {
        if (e.keyCode === 13) {
            let btn = document.getElementById('addBtn');
            btn.click();
        }
    }

    render() {
        return (
            <div className='appBody'>
                <input onKeyUp={(e) => this.checkForEnter(e)}
                       onChange={(e) => this.inputChanged(e)}
                       value={this.state.userInput}
                       placeholder={'enter friends name'}
                       type={'text'}/>
                <button id={'addBtn'}
                        onClick={() => this.addFriendToList()}>ADD</button>
                <div className='list'>
                    {this.partyList.map(name => {
                        return <div>• {name}</div>
                    })}
                </div>
            </div>
        );
    }
}